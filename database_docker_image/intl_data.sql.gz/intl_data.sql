-- Adminer 4.7.7 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

USE `intl_data`;

CREATE TABLE `avantage_inconvenient` (
  `id_avantage_inconvenient` int(11) NOT NULL AUTO_INCREMENT,
  `contenu` varchar(2048) NOT NULL,
  `avantage` tinyint(1) NOT NULL,
  `displayed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `avoir_expertise` (
  `id_domaine_etude` int(11) NOT NULL,
  `id_organisation` int(11) NOT NULL,
  PRIMARY KEY (`id_domaine_etude`,`id_organisation`),
  KEY `FK_avoir_expertise_id_organisation` (`id_organisation`),
  CONSTRAINT `FK_avoir_expertise_id_domaine_etude` FOREIGN KEY (`id_domaine_etude`) REFERENCES `domaine_etude` (`id_domaine_etude`),
  CONSTRAINT `FK_avoir_expertise_id_organisation` FOREIGN KEY (`id_organisation`) REFERENCES `organisation` (`id_organisation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `avoir_reponse` (
  `numero` int(11) NOT NULL,
  `id_experience` int(11) NOT NULL,
  `id_question` int(11) NOT NULL,
  `id_reponse_possible` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_experience`,`id_question`),
  KEY `FK_avoir_reponse_id_question` (`id_question`),
  KEY `numero` (`numero`),
  KEY `id_reponse_possible` (`id_reponse_possible`),
  CONSTRAINT `FK_avoir_reponse_id_experience` FOREIGN KEY (`id_experience`) REFERENCES `experience` (`id_experience`) ON DELETE CASCADE,
  CONSTRAINT `FK_avoir_reponse_id_question` FOREIGN KEY (`id_question`) REFERENCES `question` (`id_question`),
  CONSTRAINT `avoir_reponse_ibfk_1` FOREIGN KEY (`id_reponse_possible`) REFERENCES `reponse_possible` (`id_reponse_possible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `certification` (
  `id_certification` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) DEFAULT NULL,
  `siteweb` varchar(512) DEFAULT NULL,
  `description` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`id_certification`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `continent` (
  `id_continent` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(64) NOT NULL,
  PRIMARY KEY (`id_continent`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `continent` (`id_continent`, `nom`) VALUES
(6,	'Africa'),
(7,	'Antarctica'),
(2,	'Asia'),
(1,	'Europe'),
(3,	'North America'),
(5,	'Oceania'),
(4,	'South America'),
(0,	'Unknown');

CREATE TABLE `critiquer_ecole` (
  `id_avantage_inconvenient` int(11) NOT NULL,
  `id_organisation` int(11) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`,`id_organisation`),
  KEY `FK_critiquer_ecole_id_organisation` (`id_organisation`),
  CONSTRAINT `FK_critiquer_ecole_id_avantage_inconvenient` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_ecole_id_organisation` FOREIGN KEY (`id_organisation`) REFERENCES `organisation` (`id_organisation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `critiquer_logement` (
  `id_avantage_inconvenient` int(11) NOT NULL,
  `id_logement` int(11) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`,`id_logement`),
  KEY `FK_critiquer_logement_id_logement` (`id_logement`),
  CONSTRAINT `critiquer_logement_ibfk_1` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`) ON DELETE CASCADE,
  CONSTRAINT `critiquer_logement_ibfk_2` FOREIGN KEY (`id_logement`) REFERENCES `logement` (`id_logement`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `critiquer_pays` (
  `id_avantage_inconvenient` int(11) NOT NULL,
  `id_pays` int(11) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`,`id_pays`),
  KEY `FK_critiquer_pays_id_pays` (`id_pays`),
  CONSTRAINT `FK_critiquer_pays_id_avantage_inconvenient` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_pays_id_pays` FOREIGN KEY (`id_pays`) REFERENCES `pays` (`id_pays`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `critiquer_type_experience` (
  `id_avantage_inconvenient` int(11) NOT NULL,
  `id_type_experience` int(11) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`,`id_type_experience`),
  KEY `FK_critiquer_type_experience_id_type_experience` (`id_type_experience`),
  CONSTRAINT `FK_critiquer_type_experience_id_avantage_inconvenient` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_type_experience_id_type_experience` FOREIGN KEY (`id_type_experience`) REFERENCES `type_experience` (`id_type_experience`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `critiquer_type_logement` (
  `id_avantage_inconvenient` int(11) NOT NULL,
  `id_type_logement` int(11) NOT NULL,
  PRIMARY KEY (`id_avantage_inconvenient`,`id_type_logement`),
  KEY `FK_critiquer_type_logement_id_type_logement` (`id_type_logement`),
  CONSTRAINT `FK_critiquer_type_logement_id_avantage_inconvenient` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_type_logement_id_type_logement` FOREIGN KEY (`id_type_logement`) REFERENCES `type_logement` (`id_type_logement`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `critiquer_ville` (
  `id_ville` int(11) NOT NULL,
  `id_avantage_inconvenient` int(11) NOT NULL,
  PRIMARY KEY (`id_ville`,`id_avantage_inconvenient`),
  KEY `FK_critiquer_ville_id_avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_ville_id_avantage_inconvenient` FOREIGN KEY (`id_avantage_inconvenient`) REFERENCES `avantage_inconvenient` (`id_avantage_inconvenient`),
  CONSTRAINT `FK_critiquer_ville_id_ville` FOREIGN KEY (`id_ville`) REFERENCES `ville` (`id_ville`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `domaine_etude` (
  `id_domaine_etude` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  `id_domaine_etude_1` int(11) NOT NULL,
  PRIMARY KEY (`id_domaine_etude`),
  UNIQUE KEY `nom` (`nom`),
  KEY `FK_domaine_etude_id_domaine_etude_1` (`id_domaine_etude_1`),
  CONSTRAINT `FK_domaine_etude_id_domaine_etude_1` FOREIGN KEY (`id_domaine_etude_1`) REFERENCES `domaine_etude` (`id_domaine_etude`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `echelle_reponse` (
  `id_echelle_reponse` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  PRIMARY KEY (`id_echelle_reponse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `echelle_reponse` (`id_echelle_reponse`, `nom`) VALUES
(1,	'year of study'),
(2,	'sureness'),
(3,	'wan to go'),
(4,	'financial concerns'),
(5,	'language skill'),
(6,	'feeling new situations'),
(7,	'reaction new people'),
(8,	'ability to adapt'),
(9,	'campus'),
(10,	'number one reason'),
(11,	'nature of the mission'),
(12,	'find mission'),
(13,	'agree4'),
(14,	'agree7'),
(15,	'impact');

CREATE TABLE `etre_interesse` (
  `id_domaine_etude` int(11) NOT NULL,
  `id_etudiant` int(11) NOT NULL,
  PRIMARY KEY (`id_domaine_etude`,`id_etudiant`),
  KEY `FK_etre_interesse_id_etudiant` (`id_etudiant`),
  CONSTRAINT `FK_etre_interesse_id_domaine_etude` FOREIGN KEY (`id_domaine_etude`) REFERENCES `domaine_etude` (`id_domaine_etude`),
  CONSTRAINT `FK_etre_interesse_id_etudiant` FOREIGN KEY (`id_etudiant`) REFERENCES `etudiant` (`id_etudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `etre_utilisable` (
  `id_ville` int(11) NOT NULL,
  `id_transport` int(11) NOT NULL,
  PRIMARY KEY (`id_ville`,`id_transport`),
  KEY `FK_etre_utilisable_id_transport` (`id_transport`),
  CONSTRAINT `FK_etre_utilisable_id_transport` FOREIGN KEY (`id_transport`) REFERENCES `transport` (`id_transport`),
  CONSTRAINT `FK_etre_utilisable_id_ville` FOREIGN KEY (`id_ville`) REFERENCES `ville` (`id_ville`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `etudiant` (
  `id_etudiant` int(11) NOT NULL,
  `prenom` varchar(64) DEFAULT NULL,
  `nom` varchar(64) DEFAULT NULL,
  `genre` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id_etudiant`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `exiger_score` (
  `score` int(11) NOT NULL,
  `page_plus_infos` varchar(512) DEFAULT NULL,
  `id_certification` int(11) NOT NULL,
  `id_organisation` int(11) NOT NULL,
  PRIMARY KEY (`id_certification`,`id_organisation`),
  KEY `FK_exiger_score_id_organisation` (`id_organisation`),
  CONSTRAINT `FK_exiger_score_id_certification` FOREIGN KEY (`id_certification`) REFERENCES `certification` (`id_certification`),
  CONSTRAINT `FK_exiger_score_id_organisation` FOREIGN KEY (`id_organisation`) REFERENCES `organisation` (`id_organisation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `experience` (
  `id_experience` int(11) NOT NULL AUTO_INCREMENT,
  `age` int(11) DEFAULT NULL,
  `duree` float DEFAULT NULL,
  `competences_acquises` text DEFAULT NULL,
  `choses_faites` text DEFAULT NULL,
  `cout` int(11) DEFAULT NULL,
  `cout_location` int(11) DEFAULT NULL,
  `cout_alimentation` int(11) DEFAULT NULL,
  `cout_formation` int(11) DEFAULT NULL,
  `cout_recherche_agence` int(11) DEFAULT NULL,
  `pret` tinyint(1) DEFAULT NULL,
  `somme_empruntee` int(11) DEFAULT NULL,
  `ressenti_langue` text DEFAULT NULL,
  `surprise` text DEFAULT NULL,
  `made_angry` text DEFAULT NULL,
  `made_laugh` text DEFAULT NULL,
  `what_missed` text DEFAULT NULL,
  `things_appreciated_want_integrate_now` text DEFAULT NULL,
  `interact_same_way` text DEFAULT NULL,
  `differences_time_organization` text DEFAULT NULL,
  `advice` text DEFAULT NULL,
  `most_difficult` text DEFAULT NULL,
  `agresso_ui` int(11) DEFAULT NULL,
  `id_type_experience` int(11) DEFAULT NULL,
  `id_logement` int(11) DEFAULT NULL,
  `id_etudiant` int(11) DEFAULT NULL,
  `id_organisation` int(11) DEFAULT NULL,
  `id_langue` int(11) DEFAULT NULL,
  `id_groupe_questions` int(11) DEFAULT 2,
  `done` tinyint(1) NOT NULL DEFAULT 0,
  `date` date DEFAULT NULL,
  `logement_trouve` text DEFAULT NULL,
  `id_avantage_logement` int(11) DEFAULT NULL,
  `id_inconvenient_logement` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_experience`),
  KEY `FK_experience_id_etudiant` (`id_etudiant`),
  KEY `FK_experience_id_groupe_questions` (`id_groupe_questions`),
  KEY `FK_experience_id_type_experience` (`id_type_experience`),
  KEY `FK_experience_id_langue` (`id_langue`),
  KEY `FK_experience_id_logement` (`id_logement`),
  KEY `FK_experience_id_organisation` (`id_organisation`),
  CONSTRAINT `FK_experience_id_langue` FOREIGN KEY (`id_langue`) REFERENCES `langue` (`id_langue`),
  CONSTRAINT `FK_experience_id_logement` FOREIGN KEY (`id_logement`) REFERENCES `logement` (`id_logement`),
  CONSTRAINT `FK_experience_id_organisation` FOREIGN KEY (`id_organisation`) REFERENCES `organisation` (`id_organisation`),
  CONSTRAINT `FK_experience_id_type_experience` FOREIGN KEY (`id_type_experience`) REFERENCES `type_experience` (`id_type_experience`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;


CREATE TABLE `experience_onlyrid_view` (`id_experience_view` int(11), `study year rid` decimal(32,0), `age` int(11), `believe enrich rid` decimal(32,0), `believe help improve language skills rid` decimal(32,0), `believe put into practice knowledge rid` decimal(32,0), `believe make more interesting rid` decimal(32,0), `Feelings about the Mission rid` decimal(32,0), `language skills before rid` decimal(32,0), `dealing with the unknow before rid` decimal(32,0), `meeting new people before rid` decimal(32,0), `adaptability before rid` decimal(32,0), `campus rid` decimal(32,0), `nature of the mission` varchar(128), `nature of the mission id` int(11), `reason for the mission rid` decimal(32,0), `duration` float, `organization` varchar(25), `organization id` int(11), `How did the student find out about this Mission? rid` decimal(32,0), `new skills gained` text, `what did the student do ?` text, `transport cost` int(11), `education cost` int(11), `food cost` int(11), `agency cost` int(11), `loan` tinyint(1), `borrowed money` int(11), `accommodation` varchar(128), `accommodation id` int(11), `accomodation advantage` varchar(2048), `accomodation disadvantage` varchar(2048), `How did the student find the accomodation?` text, `recommend rid` decimal(32,0), `language used` varchar(25), `language used id` int(11), `language feeling` text, `what surprised the student` text, `what made the student angry` text, `what made the student laugh` text, `what the student missed` text, `things from the country that the student really appreciated` text, `differences in the way people interact` text, `differences in the way that time is organized` text, `advice` text, `most difficult to get accustomed to` text, `financial concerns rid` decimal(32,0), `the student is happy to have had this experience rid` decimal(32,0), `The student learned a lot from this experience rid` decimal(32,0), `This experience will help the student in its future studies rid` decimal(32,0), `This experience will help the student in its future career rid` decimal(32,0), `experience part of professional development plan rid` decimal(32,0), `look great on CV rid` decimal(32,0), `improve language skills rid` decimal(32,0), `improve social skills rid` decimal(32,0), `increase self-confidence rid` decimal(32,0), `improve its ability to face difficulty rid` decimal(32,0), `less worried by new experiences rid` decimal(32,0), `started to feel at home rid` decimal(32,0), `miss certain things about the country rid` decimal(32,0), `intend to stay in touch rid` decimal(32,0), `want to return to the country rid` decimal(32,0), `want to go abroad again rid` decimal(32,0), `overall rating rid` decimal(32,0), `enrich rid` decimal(32,0), `help improve language skills rid` decimal(32,0), `put into practice knowledge rid` decimal(32,0), `made more interesting rid` decimal(32,0), `language skills rid` decimal(32,0), `dealing with the unknow rid` decimal(32,0), `meeting new people rid` decimal(32,0), `adaptability rid` decimal(32,0), `AGRESSO uid` int(11), `firstname` varchar(64), `lastname` varchar(64), `gender` int(10) unsigned, `student` varchar(64), `student id` int(11), `country id` int(11), `country` varchar(64), `accomodation cost` float, `city` varchar(128), `city id` int(11), `continent` varchar(64), `continent id` int(11));


CREATE TABLE `experience_view` (`id_experience_view` int(11), `study year rid` decimal(32,0), `age` int(11), `believe enrich rid` decimal(32,0), `believe help improve language skills rid` decimal(32,0), `believe put into practice knowledge rid` decimal(32,0), `believe make more interesting rid` decimal(32,0), `Feelings about the Mission rid` decimal(32,0), `language skills before rid` decimal(32,0), `dealing with the unknow before rid` decimal(32,0), `meeting new people before rid` decimal(32,0), `adaptability before rid` decimal(32,0), `campus rid` decimal(32,0), `nature of the mission` varchar(128), `nature of the mission id` int(11), `reason for the mission rid` decimal(32,0), `duration` float, `organization` varchar(25), `organization id` int(11), `How did the student find out about this Mission? rid` decimal(32,0), `new skills gained` text, `what did the student do ?` text, `transport cost` int(11), `education cost` int(11), `food cost` int(11), `agency cost` int(11), `loan` tinyint(1), `borrowed money` int(11), `accommodation` varchar(128), `accommodation id` int(11), `accomodation advantage` varchar(2048), `accomodation disadvantage` varchar(2048), `How did the student find the accomodation?` text, `recommend rid` decimal(32,0), `language used` varchar(25), `language used id` int(11), `language feeling` text, `what surprised the student` text, `what made the student angry` text, `what made the student laugh` text, `what the student missed` text, `things from the country that the student really appreciated` text, `differences in the way people interact` text, `differences in the way that time is organized` text, `advice` text, `most difficult to get accustomed to` text, `financial concerns rid` decimal(32,0), `the student is happy to have had this experience rid` decimal(32,0), `The student learned a lot from this experience rid` decimal(32,0), `This experience will help the student in its future studies rid` decimal(32,0), `This experience will help the student in its future career rid` decimal(32,0), `experience part of professional development plan rid` decimal(32,0), `look great on CV rid` decimal(32,0), `improve language skills rid` decimal(32,0), `improve social skills rid` decimal(32,0), `increase self-confidence rid` decimal(32,0), `improve its ability to face difficulty rid` decimal(32,0), `less worried by new experiences rid` decimal(32,0), `started to feel at home rid` decimal(32,0), `miss certain things about the country rid` decimal(32,0), `intend to stay in touch rid` decimal(32,0), `want to return to the country rid` decimal(32,0), `want to go abroad again rid` decimal(32,0), `overall rating rid` decimal(32,0), `enrich rid` decimal(32,0), `help improve language skills rid` decimal(32,0), `put into practice knowledge rid` decimal(32,0), `made more interesting rid` decimal(32,0), `language skills rid` decimal(32,0), `dealing with the unknow rid` decimal(32,0), `meeting new people rid` decimal(32,0), `adaptability rid` decimal(32,0), `AGRESSO uid` int(11), `firstname` varchar(64), `lastname` varchar(64), `gender` int(10) unsigned, `student` varchar(64), `student id` int(11), `country id` int(11), `country` varchar(64), `accomodation cost` float, `city` varchar(128), `city id` int(11), `continent` varchar(64), `continent id` int(11), `study year` text, `study year num` int(11), `believe enrich` text, `believe enrich num` int(11), `believe help improve language skills` text, `believe help improve language skills num` int(11), `believe put into practice knowledge` text, `believe put into practice knowledge num` int(11), `believe make more interesting` text, `believe make more interesting num` int(11), `Feelings about the Mission` text, `Feelings about the Mission num` int(11), `language skills before` text, `language skills before num` int(11), `dealing with the unknow before` text, `dealing with the unknow before num` int(11), `meeting new people before` text, `meeting new people before num` int(11), `adaptability before` text, `adaptability before num` int(11), `campus` text, `campus num` int(11), `reason for the mission` text, `reason for the mission num` int(11), `How did the student find out about this Mission?` text, `How did the student find out about this Mission? num` int(11), `recommend` text, `recommend num` int(11), `financial concerns` text, `financial concerns num` int(11), `the student is happy to have had this experience` text, `the student is happy to have had this experience num` int(11), `The student learned a lot from this experience` text, `The student learned a lot from this experience num` int(11), `This experience will help the student in its future studies` text, `This experience will help the student in its future studies num` int(11), `This experience will help the student in its future career` text, `This experience will help the student in its future career num` int(11), `experience part of professional development plan` text, `experience part of professional development plan num` int(11), `look great on CV` text, `look great on CV num` int(11), `improve language skills` text, `improve language skills num` int(11), `improve social skills` text, `improve social skills num` int(11), `increase self-confidence` text, `increase self-confidence num` int(11), `improve its ability to face difficulty` text, `improve its ability to face difficulty num` int(11), `less worried by new experiences` text, `less worried by new experiences num` int(11), `started to feel at home` text, `started to feel at home num` int(11), `miss certain things about the country` text, `miss certain things about the country num` int(11), `intend to stay in touch` text, `intend to stay in touch num` int(11), `want to return to the country` text, `want to return to the country num` int(11), `want to go abroad again` text, `want to go abroad again num` int(11), `overall rating` text, `overall rating num` int(11), `enrich` text, `enrich num` int(11), `help improve language skills` text, `help improve language skills num` int(11), `put into practice knowledge` text, `put into practice knowledge num` int(11), `made more interesting` text, `made more interesting num` int(11), `language skills` text, `language skills num` int(11), `dealing with the unknow` text, `dealing with the unknow num` int(11), `meeting new people` text, `meeting new people num` int(11), `adaptability` text, `adaptability num` int(11));


CREATE TABLE `groupe_questions` (
  `id_groupe_questions` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  `need_experience_done` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_groupe_questions`),
  UNIQUE KEY `ordre` (`ordre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `groupe_questions` (`id_groupe_questions`, `nom`, `ordre`, `need_experience_done`) VALUES
(2,	'Your mission',	0,	0),
(3,	'Before going',	1,	0),
(4,	'Financial concerns',	2,	1),
(5,	'After going',	3,	1),
(6,	'Accommodation',	4,	1),
(7,	'Outcome',	5,	1),
(8,	'Stories',	6,	1);

CREATE TABLE `langue` (
  `id_langue` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  PRIMARY KEY (`id_langue`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `logement` (
  `id_logement` int(11) NOT NULL AUTO_INCREMENT,
  `prix` float DEFAULT NULL,
  `id_type_logement` int(11) DEFAULT NULL,
  `id_ville` int(11) NOT NULL,
  `nom` varchar(128) DEFAULT NULL,
  `adresse` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id_logement`),
  KEY `FK_logement_id_type_logement` (`id_type_logement`),
  KEY `FK_logement_id_ville` (`id_ville`),
  CONSTRAINT `FK_logement_id_type_logement` FOREIGN KEY (`id_type_logement`) REFERENCES `type_logement` (`id_type_logement`),
  CONSTRAINT `FK_logement_id_ville` FOREIGN KEY (`id_ville`) REFERENCES `ville` (`id_ville`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `organisation` (
  `id_organisation` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  `nombre_etudiants` int(11) DEFAULT NULL,
  `site_web` varchar(255) DEFAULT NULL,
  `prix` float DEFAULT NULL,
  `commentaire` varchar(1024) DEFAULT NULL,
  `disponible` tinyint(1) DEFAULT NULL,
  `id_langue` int(11) NOT NULL,
  `id_ville` int(11) NOT NULL,
  `estEcole` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_organisation`),
  KEY `FK_organisation_id_langue` (`id_langue`),
  KEY `FK_organisation_id_ville` (`id_ville`),
  CONSTRAINT `FK_organisation_id_ville` FOREIGN KEY (`id_ville`) REFERENCES `ville` (`id_ville`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `parler` (
  `id_pays` int(11) NOT NULL,
  `id_langue` int(11) NOT NULL,
  PRIMARY KEY (`id_pays`,`id_langue`),
  KEY `FK_parler_id_langue` (`id_langue`),
  CONSTRAINT `FK_parler_id_langue` FOREIGN KEY (`id_langue`) REFERENCES `langue` (`id_langue`),
  CONSTRAINT `FK_parler_id_pays` FOREIGN KEY (`id_pays`) REFERENCES `pays` (`id_pays`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `pays` (
  `id_pays` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(64) NOT NULL,
  `id_continent` int(11) NOT NULL,
  PRIMARY KEY (`id_pays`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `pays` (`id_pays`, `nom`, `id_continent`) VALUES
(13453,	'Rwanda',	6),
(13454,	'Somalia',	6),
(13455,	'Yemen',	2),
(13456,	'Iraq',	2),
(13457,	'Saudi Arabia',	2),
(13458,	'Iran',	2),
(13459,	'Cyprus',	1),
(13460,	'Tanzania',	6),
(13461,	'Syria',	2),
(13462,	'Armenia',	2),
(13463,	'Kenya',	6),
(13464,	'Congo',	6),
(13465,	'Uganda',	6),
(13466,	'Central African Republic',	6),
(13467,	'Seychelles',	6),
(13468,	'Hashemite Kingdom of Jordan',	2),
(13469,	'Lebanon',	2),
(13470,	'Kuwait',	2),
(13471,	'Oman',	2),
(13472,	'Djibouti',	6),
(13473,	'Qatar',	2),
(13474,	'Bahrain',	2),
(13475,	'United Arab Emirates',	2),
(13476,	'Turkey',	2),
(13477,	'Ethiopia',	6),
(13478,	'Eritrea',	6),
(13479,	'Egypt',	6),
(13480,	'Israel',	2),
(13481,	'Greece',	1),
(13482,	'Burundi',	6),
(13483,	'Sudan',	6),
(13484,	'Estonia',	1),
(13485,	'Latvia',	1),
(13486,	'Azerbaijan',	2),
(13487,	'Republic of Lithuania',	1),
(13488,	'Svalbard and Jan Mayen',	1),
(13489,	'Georgia',	2),
(13490,	'Republic of Moldova',	1),
(13491,	'Belarus',	1),
(13492,	'Finland',	1),
(13493,	'Åland',	1),
(13494,	'Ukraine',	1),
(13495,	'Macedonia',	1),
(13496,	'Hungary',	1),
(13497,	'Bulgaria',	1),
(13498,	'Albania',	1),
(13499,	'Poland',	1),
(13500,	'Romania',	1),
(13501,	'Kosovo',	1),
(13502,	'Zimbabwe',	6),
(13503,	'Zambia',	6),
(13504,	'Comoros',	6),
(13505,	'Malawi',	6),
(13506,	'Lesotho',	6),
(13507,	'Mauritius',	6),
(13508,	'Swaziland',	6),
(13509,	'Réunion',	6),
(13510,	'South Africa',	6),
(13511,	'Mayotte',	6),
(13512,	'Mozambique',	6),
(13513,	'Madagascar',	6),
(13514,	'Botswana',	6),
(13515,	'Pakistan',	2),
(13516,	'Afghanistan',	2),
(13517,	'Bangladesh',	2),
(13518,	'Turkmenistan',	2),
(13519,	'Tajikistan',	2),
(13520,	'Sri Lanka',	2),
(13521,	'Bhutan',	2),
(13522,	'India',	2),
(13523,	'British Indian Ocean Territory',	2),
(13524,	'Maldives',	2),
(13525,	'Nepal',	2),
(13526,	'Uzbekistan',	2),
(13527,	'Kazakhstan',	2),
(13528,	'Kyrgyzstan',	2),
(13529,	'French Southern Territories',	7),
(13530,	'Myanmar [Burma]',	2),
(13531,	'Heard Island and McDonald Islands',	7),
(13532,	'Cocos [Keeling] Islands',	2),
(13533,	'Palau',	5),
(13534,	'Vietnam',	2),
(13535,	'Indonesia',	2),
(13536,	'Laos',	2),
(13537,	'Taiwan',	2),
(13538,	'Philippines',	2),
(13539,	'Thailand',	2),
(13540,	'China',	2),
(13541,	'Hong Kong',	2),
(13542,	'Brunei',	2),
(13543,	'Malaysia',	2),
(13544,	'Macao',	2),
(13545,	'Republic of Korea',	2),
(13546,	'Japan',	2),
(13547,	'North Korea',	2),
(13548,	'Singapore',	2),
(13549,	'Cook Islands',	5),
(13550,	'East Timor',	5),
(13551,	'Russia',	1),
(13552,	'Cambodia',	2),
(13553,	'Mongolia',	2),
(13554,	'Australia',	5),
(13555,	'Christmas Island',	2),
(13556,	'Federated States of Micronesia',	5),
(13557,	'Papua New Guinea',	5),
(13558,	'Solomon Islands',	5),
(13559,	'Tuvalu',	5),
(13560,	'Nauru',	5),
(13561,	'Vanuatu',	5),
(13562,	'New Caledonia',	5),
(13563,	'Norfolk Island',	5),
(13564,	'Marshall Islands',	5),
(13565,	'New Zealand',	5),
(13566,	'Fiji',	5),
(13567,	'Libya',	6),
(13568,	'Cameroon',	6),
(13569,	'Republic of the Congo',	6),
(13570,	'Portugal',	1),
(13571,	'Liberia',	6),
(13572,	'Ivory Coast',	6),
(13573,	'Ghana',	6),
(13574,	'Senegal',	6),
(13575,	'Nigeria',	6),
(13576,	'Equatorial Guinea',	6),
(13577,	'Burkina Faso',	6),
(13578,	'Guinea-Bissau',	6),
(13579,	'Mauritania',	6),
(13580,	'Benin',	6),
(13581,	'Gabon',	6),
(13582,	'Sierra Leone',	6),
(13583,	'São Tomé and Príncipe',	6),
(13584,	'Gibraltar',	1),
(13585,	'Togo',	6),
(13586,	'Guinea',	6),
(13587,	'Gambia',	6),
(13588,	'Chad',	6),
(13589,	'Mali',	6),
(13590,	'Western Sahara',	6),
(13591,	'Tunisia',	6),
(13592,	'Spain',	1),
(13593,	'Morocco',	6),
(13594,	'Niger',	6),
(13595,	'Malta',	1),
(13596,	'Faroe Islands',	1),
(13597,	'Algeria',	6),
(13598,	'Iceland',	1),
(13599,	'United Kingdom',	1),
(13600,	'Switzerland',	1),
(13601,	'Sweden',	1),
(13602,	'Netherlands',	1),
(13603,	'Austria',	1),
(13604,	'Denmark',	1),
(13605,	'Germany',	1),
(13606,	'Belgium',	1),
(13607,	'Luxembourg',	1),
(13608,	'Monaco',	1),
(13609,	'France',	1),
(13610,	'Andorra',	1),
(13611,	'Liechtenstein',	1),
(13612,	'Ireland',	1),
(13613,	'Isle of Man',	1),
(13614,	'Guernsey',	1),
(13615,	'Slovakia',	1),
(13616,	'Czechia',	1),
(13617,	'Jersey',	1),
(13618,	'Norway',	1),
(13619,	'San Marino',	1),
(13620,	'Italy',	1),
(13621,	'Vatican City',	1),
(13622,	'Slovenia',	1),
(13623,	'Croatia',	1),
(13624,	'Bosnia and Herzegovina',	1),
(13625,	'Angola',	6),
(13626,	'Namibia',	6),
(13627,	'Montenegro',	1),
(13628,	'Saint Helena',	6),
(13629,	'Cape Verde',	6),
(13630,	'Guyana',	4),
(13631,	'Barbados',	3),
(13632,	'Suriname',	4),
(13633,	'Saint Pierre and Miquelon',	3),
(13634,	'Greenland',	3),
(13635,	'Paraguay',	4),
(13636,	'French Guiana',	4),
(13637,	'Uruguay',	4),
(13638,	'Brazil',	4),
(13639,	'Falkland Islands',	4),
(13640,	'Jamaica',	3),
(13641,	'Dominican Republic',	3),
(13642,	'Cuba',	3),
(13643,	'Martinique',	3),
(13644,	'Bahamas',	3),
(13645,	'Bermuda',	3),
(13646,	'Anguilla',	3),
(13647,	'South Georgia and the South Sandwich Islands',	7),
(13648,	'Trinidad and Tobago',	3),
(13649,	'St Kitts and Nevis',	3),
(13650,	'Dominica',	3),
(13651,	'Saint Lucia',	3),
(13652,	'Turks and Caicos Islands',	3),
(13653,	'Aruba',	3),
(13654,	'British Virgin Islands',	3),
(13655,	'Saint Vincent and the Grenadines',	3),
(13656,	'Montserrat',	3),
(13657,	'Saint Martin',	3),
(13658,	'Antigua and Barbuda',	3),
(13659,	'Saint-Barthélemy',	3),
(13660,	'Guadeloupe',	3),
(13661,	'Grenada',	3),
(13662,	'Belize',	3),
(13663,	'El Salvador',	3),
(13664,	'Guatemala',	3),
(13665,	'Honduras',	3),
(13666,	'Cayman Islands',	3),
(13667,	'Nicaragua',	3),
(13668,	'Costa Rica',	3),
(13669,	'Venezuela',	4),
(13670,	'Ecuador',	4),
(13671,	'Colombia',	4),
(13672,	'Panama',	3),
(13673,	'Haiti',	3),
(13674,	'Argentina',	4),
(13675,	'Chile',	4),
(13676,	'Bolivia',	4),
(13677,	'Peru',	4),
(13678,	'Mexico',	3),
(13679,	'French Polynesia',	5),
(13680,	'Pitcairn Islands',	5),
(13681,	'Tokelau',	5),
(13682,	'Tonga',	5),
(13683,	'Wallis and Futuna',	5),
(13684,	'Samoa',	5),
(13685,	'Niue',	5),
(13686,	'Kiribati',	5),
(13687,	'Northern Mariana Islands',	5),
(13688,	'Puerto Rico',	3),
(13689,	'U.S. Virgin Islands',	3),
(13690,	'U.S. Minor Outlying Islands',	5),
(13691,	'American Samoa',	5),
(13692,	'Canada',	3),
(13693,	'Guam',	5),
(13694,	'Palestine',	2),
(13695,	'Serbia',	1),
(13696,	'United States',	3),
(13697,	'Antarctica',	7),
(13698,	'Sint Maarten',	3),
(13699,	'Curaçao',	3),
(13700,	'South Sudan',	6),
(13701,	'Bonaire, Sint Eustatius, and Saba',	3),
(13702,	'Unknown',	0);

CREATE TABLE `question` (
  `id_question` int(11) NOT NULL AUTO_INCREMENT,
  `texte` varchar(512) DEFAULT NULL,
  `optionelle` tinyint(1) NOT NULL,
  `identifiant` varchar(255) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `id_echelle_reponse` int(11) DEFAULT NULL,
  `ordre` int(11) DEFAULT NULL,
  `id_groupe_questions` int(11) NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT 1,
  `name` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id_question`),
  KEY `FK_question_id_echelle_reponse` (`id_echelle_reponse`),
  KEY `FK_question_id_groupe_questions` (`id_groupe_questions`),
  KEY `unique_name` (`name`),
  CONSTRAINT `FK_question_id_echelle_reponse` FOREIGN KEY (`id_echelle_reponse`) REFERENCES `echelle_reponse` (`id_echelle_reponse`),
  CONSTRAINT `FK_question_id_groupe_questions` FOREIGN KEY (`id_groupe_questions`) REFERENCES `groupe_questions` (`id_groupe_questions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `question` (`id_question`, `texte`, `optionelle`, `identifiant`, `type`, `id_echelle_reponse`, `ordre`, `id_groupe_questions`, `enabled`, `name`) VALUES
(1,	'Your year of study at the time of your Mission',	0,	'',	1,	1,	0,	2,	1,	'study year'),
(3,	'Your age at the time of your Mission',	0,	'age',	2,	NULL,	1,	2,	1,	'age'),
(4,	'I believe that this mission... [will enrich me as a person.]',	0,	'',	1,	2,	NULL,	3,	1,	'believe enrich'),
(5,	'I believe that this mission... [will help me to improve my language skills.]',	0,	'',	1,	2,	NULL,	3,	1,	'believe help improve language skills'),
(6,	'I believe that this mission... [will help me better understand and put into practice what I have learned during my studies.]',	0,	'',	1,	2,	NULL,	3,	1,	'believe put into practice knowledge'),
(7,	'I believe that this mission... [will make me a more interesting candidate for recruiters.]',	0,	'',	1,	2,	NULL,	3,	1,	'believe make more interesting'),
(10,	'How do you feel about going on this Mission? [Feelings about the Mission]',	0,	'',	1,	3,	NULL,	3,	1,	'Feelings about the Mission'),
(12,	'How would you evaluate your language skills before going on the mission? [Target Language Skills]',	0,	'',	1,	5,	NULL,	3,	1,	'language skills before'),
(13,	'How do you feel about facing new and unknown situations and environments? [Dealing with the unknown]',	0,	'',	1,	6,	NULL,	3,	1,	'dealing with the unknow before'),
(14,	'How do you react when you are meeting people for the first time? [Meeting new people]',	0,	'',	1,	7,	NULL,	3,	1,	'meeting new people before'),
(15,	'How would you evaluate your ability to adapt to new situations and environments? [Adaptability]',	0,	'',	1,	8,	NULL,	3,	1,	'adaptability before'),
(16,	'Your Campus',	0,	'',	1,	9,	2,	2,	1,	'campus'),
(18,	'What is the nature of your mission?',	0,	'id_type_experience',	4,	NULL,	3,	2,	1,	'nature of the mission'),
(19,	'What is the Number One reason you decided to go on this Mission in particular?',	0,	'',	1,	10,	8,	2,	1,	'reason for the mission'),
(22,	'Select the country you are going to:',	1,	'id_pays',	4,	NULL,	4,	2,	1,	'country'),
(23,	'Select the city you are going to:',	1,	'id_ville',	4,	NULL,	4,	2,	1,	'city'),
(24,	'Duration of your Mission, expressed in number of months',	0,	'duree',	2,	NULL,	7,	2,	1,	'duration'),
(25,	'Select your organization (School or company) or add a new one.',	0,	'id_organisation',	4,	NULL,	6,	2,	1,	'organization'),
(26,	'How did you find out about this Mission?',	0,	'',	1,	12,	9,	2,	1,	'How did the student find out about this Mission?'),
(27,	'What new skills and knowledge did you gain during this Mission?',	0,	'competences_acquises',	5,	NULL,	NULL,	7,	1,	'new skills gained'),
(28,	'What did you do during your Mission?',	0,	'choses_faites',	5,	NULL,	NULL,	7,	1,	'what did the student do ?'),
(29,	'What was the cost of the trip itself (airfare, trainfare, ferry, etc.) ROUND TRIP?',	0,	'cout',	2,	NULL,	NULL,	4,	1,	'transport cost'),
(30,	'How much did you spend on tuition fees (frais d\'inscription/études)?',	0,	'cout_formation',	2,	NULL,	NULL,	4,	1,	'education cost'),
(31,	'How much did you spend on food per month?',	0,	'cout_alimentation',	2,	NULL,	NULL,	4,	1,	'food cost'),
(32,	'How much did you pay an agency (CEI, EuropUSA, etc.) to find the job/internship for you?',	1,	'cout_recherche_agence',	2,	NULL,	NULL,	4,	1,	'agency cost'),
(33,	'Did you take out a loan (prêt bancaire) to finance your mission?',	0,	'pret',	6,	NULL,	NULL,	4,	1,	'loan'),
(34,	'How much did you borrow?',	0,	'somme_empruntee',	2,	NULL,	NULL,	4,	1,	'borrowed money'),
(47,	'Select your accomodation or add a new one.',	0,	'id_logement',	4,	NULL,	NULL,	6,	1,	'accommodation'),
(50,	'What was the best thing about your accommodation?',	0,	'id_avantage_logement/logement/critiquer_logement/avantage_inconvenient/contenu=?,avantage=1,displayed=1',	8,	NULL,	NULL,	6,	1,	'accomodation advantage'),
(51,	'What was the worst thing about your accommodation?',	0,	'id_inconvenient_logement/logement/critiquer_logement/avantage_inconvenient/contenu=?,avantage=0,displayed=1',	8,	NULL,	NULL,	6,	1,	'accomodation disadvantage'),
(52,	'How did you find your accommodation?',	0,	'logement_trouve',	5,	NULL,	NULL,	6,	1,	'How did the student find the accomodation?'),
(53,	'I would recommend this experience to other students.',	0,	'',	7,	14,	NULL,	7,	1,	'recommend'),
(54,	'Which language were you using ?',	0,	'id_langue',	4,	NULL,	NULL,	7,	1,	'language used'),
(55,	'How did you feel about language use during the mission?',	0,	'ressenti_langue',	5,	NULL,	NULL,	7,	1,	'language feeling'),
(56,	'Tell us about something that surprised you during your Mission.',	0,	'surprise',	5,	NULL,	NULL,	8,	1,	'what surprised the student'),
(57,	'Tell us about something that made you angry during your Mission.',	0,	'made_angry',	5,	NULL,	NULL,	8,	1,	'what made the student angry'),
(58,	'Tell us about something that made you laugh during your Mission.',	0,	'made_laugh',	5,	NULL,	NULL,	8,	1,	'what made the student laugh'),
(59,	'What did you miss the most from home?',	0,	'what_missed',	5,	NULL,	NULL,	8,	1,	'what the student missed'),
(60,	'Are there things from the country where you lived that you really appreciated and are trying to integrate into your life now? ',	0,	'things_appreciated_want_integrate_now',	5,	NULL,	NULL,	8,	1,	'things from the country that the student really appreciated'),
(61,	'Did people in the country where you lived interact the same way people do in France? Can you give an example to support your statement?',	0,	'interact_same_way',	5,	NULL,	NULL,	8,	1,	'differences in the way people interact'),
(62,	'What differences did you notice in the way that time is organized in the country where you lived, as compared to France?',	0,	'differences_time_organization',	5,	NULL,	NULL,	8,	1,	'differences in the way that time is organized'),
(63,	'What advice do you have for your fellow students if they go to this country?',	0,	'advice',	5,	NULL,	NULL,	8,	1,	'advice'),
(64,	'What did you find the most difficult to get accustomed to?',	0,	'most_difficult',	5,	NULL,	NULL,	8,	1,	'most difficult to get accustomed to'),
(65,	'Financial concerns',	0,	NULL,	7,	4,	NULL,	3,	1,	'financial concerns'),
(90,	'I am happy to have had this experience.',	0,	NULL,	7,	13,	NULL,	7,	1,	'the student is happy to have had this experience'),
(91,	'I learned a lot from this experience.',	0,	NULL,	7,	13,	NULL,	7,	1,	'The student learned a lot from this experience'),
(92,	'This experience will help me in my future studies.',	0,	NULL,	7,	13,	NULL,	7,	1,	'This experience will help the student in its future studies'),
(93,	'This experience will help me in my future career.',	0,	NULL,	7,	13,	NULL,	7,	1,	'This experience will help the student in its future career'),
(94,	'This experience is an integral part of my professional development plan.',	0,	NULL,	7,	13,	NULL,	7,	1,	'experience part of professional development plan'),
(95,	'This experience is going to look great on my CV.',	0,	NULL,	7,	13,	NULL,	7,	1,	'look great on CV'),
(96,	'I have improved my language skills during this mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'improve language skills'),
(97,	'I have improved my social skills during this mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'improve social skills'),
(98,	'I have more self-confidence now.',	0,	NULL,	7,	14,	NULL,	7,	1,	'increase self-confidence'),
(99,	'I have discovered that I am able to face difficulties without getting too upset.',	0,	NULL,	7,	14,	NULL,	7,	1,	'improve its ability to face difficulty'),
(100,	'New experiences worry me less now.',	0,	NULL,	7,	14,	NULL,	7,	1,	'less worried by new experiences'),
(101,	'I was starting to \"feel at home\" in the country where I performed my mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'started to feel at home'),
(102,	'I miss certain things about the country where I performed my mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'miss certain things about the country'),
(103,	'I intend to stay in touch with the new friends I made during my mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'intend to stay in touch'),
(104,	'I want to return to the country where I performed my mission.',	0,	NULL,	7,	14,	NULL,	7,	1,	'want to return to the country'),
(105,	'I want to go abroad again to discover another country.',	0,	NULL,	7,	14,	NULL,	7,	1,	'want to go abroad again'),
(106,	'What is your overall rating of this experience?',	0,	NULL,	7,	14,	NULL,	7,	1,	'overall rating'),
(107,	'This mission has... [enriched me as a person.]',	0,	NULL,	1,	15,	NULL,	5,	1,	'enrich'),
(108,	'This mission has... [helped me improve my language skills.]',	0,	NULL,	1,	15,	NULL,	5,	1,	'help improve language skills'),
(109,	'This mission has... [helped me better understand and put into practice what I have learned during my studies.]',	0,	NULL,	1,	15,	NULL,	5,	1,	'put into practice knowledge'),
(110,	'This mission has... [made me a more interesting candidate for recruiters.]',	0,	NULL,	1,	15,	NULL,	5,	1,	'made more interesting'),
(111,	'How would you evaluate your language skills now? [Target language skills]',	0,	NULL,	1,	5,	NULL,	5,	1,	'language skills'),
(112,	'How do you feel about facing new and unknown situations? [Dealing with the unknown]',	0,	NULL,	1,	6,	NULL,	5,	1,	'dealing with the unknow'),
(113,	'How do you react when you are meeting people for the first time? [Meeting new people]',	0,	NULL,	1,	7,	NULL,	5,	1,	'meeting new people'),
(114,	'How would you evaluate your ability to adapt to new situations and environments? [Adaptability]',	0,	NULL,	1,	8,	NULL,	5,	1,	'adaptability'),
(115,	'The unique identifier of your mission in AGRESSO',	0,	'agresso_ui',	2,	NULL,	10,	2,	1,	'AGRESSO uid'),
(116,	'Your firstname:',	0,	'id_etudiant///etudiant/prenom=?',	9,	NULL,	NULL,	2,	1,	'firstname'),
(117,	'Your lastname:',	0,	'id_etudiant///etudiant/nom=?',	9,	NULL,	NULL,	2,	1,	'lastname'),
(118,	'Gender',	1,	'id_etudiant///etudiant/genre=?',	9,	NULL,	NULL,	2,	0,	'gender'),
(119,	NULL,	1,	'id_etudiant',	4,	NULL,	NULL,	2,	0,	'student'),
(121,	NULL,	1,	'2:id_organisation->organisation/id_ville->ville/id_pays',	4,	NULL,	NULL,	2,	0,	'country id'),
(122,	'',	1,	'2:id_organisation->organisation/id_ville->ville/id_pays->pays/nom',	9,	NULL,	NULL,	2,	0,	'country'),
(123,	NULL,	1,	'2:id_logement->logement/prix',	2,	NULL,	NULL,	2,	0,	'accomodation cost'),
(124,	'',	1,	'2:id_organisation->organisation/id_ville->ville/nom',	9,	NULL,	NULL,	2,	0,	'city'),
(125,	NULL,	1,	'2:id_organisation->organisation/id_ville',	4,	NULL,	NULL,	2,	0,	'city id'),
(126,	NULL,	1,	'2:id_organisation->organisation/id_ville->ville/id_pays->pays/id_continent->continent/nom',	9,	NULL,	NULL,	2,	0,	'continent'),
(127,	NULL,	1,	'2:id_organisation->organisation/id_ville->ville/id_pays->pays/id_continent',	4,	NULL,	NULL,	2,	0,	'continent id');

CREATE TABLE `reponse_possible` (
  `id_reponse_possible` int(11) NOT NULL AUTO_INCREMENT,
  `texte` text NOT NULL,
  `numero` int(11) NOT NULL,
  `id_echelle_reponse` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_reponse_possible`),
  KEY `FK_reponse_possible_id_echelle_reponse` (`id_echelle_reponse`),
  KEY `numero` (`numero`),
  CONSTRAINT `FK_reponse_possible_id_echelle_reponse` FOREIGN KEY (`id_echelle_reponse`) REFERENCES `echelle_reponse` (`id_echelle_reponse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `reponse_possible` (`id_reponse_possible`, `texte`, `numero`, `id_echelle_reponse`) VALUES
(1,	'4th year or summer between 4th and 5th year',	4,	1),
(2,	'5th year and after',	5,	1),
(3,	'3rd year or summer between 3rd and 4th year',	3,	1),
(4,	'2nd year or summer between 2nd and 3rd year',	2,	1),
(5,	'1st year or summer between 1st and 2nd year',	1,	1),
(6,	'No, I\'m not at all convinced of it.',	1,	2),
(7,	'I\'m not sure and somewhat pessimistic about it.',	2,	2),
(8,	'I\'m reasonably sure of it.',	3,	2),
(9,	'I\'m convinced of it.',	4,	2),
(10,	'I don\'t want to do it and if it were not required by the school, I would not go.',	1,	3),
(11,	'I have mixed feelings about it. I know it\'s necessary but the idea of living in another country stresses me out.',	2,	3),
(12,	'I think it\'s a good idea and I\'m looking forward to it.',	3,	3),
(13,	'I hope I\'ll be able to go abroad several times during my studies',	4,	3),
(22,	'Not worried at all',	1,	4),
(23,	'Not very worried',	2,	4),
(24,	'Not worried',	3,	4),
(25,	'Rather not Worried',	4,	4),
(26,	'Rather worried',	5,	4),
(27,	'Worried',	5,	4),
(28,	'Very worried',	6,	4),
(29,	'Extremely worried',	7,	4),
(30,	'I understand everything, including TV and movies, most jokes, and I can talk about almost any topic easily.',	5,	5),
(31,	'I understand almost everything people say and I can carry on a conversation without too much stress.',	4,	5),
(32,	'I don\'t understand everything, but I get the general idea. When I speak, people get the general idea but not all the details.',	3,	5),
(33,	'I have difficulty understanding what people say and I have difficulty making myself understood by others.',	2,	5),
(34,	'I can only understand what\'s going on if there is written support material or images.',	1,	5),
(35,	'I\'m afraid of new experiences or situations where I don\'t understand/master everything. I feel out of control.',	1,	6),
(36,	'New situations make me nervous. I feel tense.',	2,	6),
(37,	'I\'m nervous but curious and excited at the same time.',	3,	6),
(38,	'New situations and environments stimulate me and I want to go and discover everything!',	4,	6),
(39,	'Campus 1',	1,	9),
(40,	'Campus 2',	2,	9),
(41,	'I seek out opportunities to meet new people. It\'s fun for me!',	4,	7),
(42,	'I smile, introduce myself and make conversation. I feel OK in this situation.',	3,	7),
(43,	'I feel timid but I manage to smile and introduce myself. I don\'t feel comfortable saying more than one or two sentences.',	2,	7),
(44,	'I really dislike meeting new people. It makes me very uncomfortable. I feel shaky.',	1,	7),
(45,	'I adapt quickly. I see what new ways of doing things I like and then I integrate them into my own behavior.',	4,	8),
(46,	'I adapt reasonably quickly. I try to imitate some of the new behaviors I see around me.',	3,	8),
(47,	'I can adapt, but slowly. I need a lot of time to look carefully at my environment and watch to see what other people do before I can adapt.',	2,	8),
(48,	'New situations are difficult and stressful for me. I don\'t feel that I can adapt successfully.',	1,	8),
(49,	'Curious about the destination and its culture',	6,	10),
(50,	'Good opportunity to improve my language skills',	5,	10),
(51,	'The timing was right',	4,	10),
(52,	'Good fit with my budget',	3,	10),
(53,	'Good fit with my professional objectives',	2,	10),
(54,	'Good fit with my academic objectives',	1,	10),
(55,	'Through a French company with a branch outside of France',	7,	12),
(56,	'Through family',	6,	12),
(57,	'Through friends',	5,	12),
(58,	'Through the international office',	4,	12),
(59,	'Through other students',	3,	12),
(60,	'Through the international day (speaker, stand, guidebook, etc.)',	2,	12),
(61,	'Through internet (job ad, etc.)',	1,	12),
(62,	'Totally Disagree',	1,	13),
(63,	'Disagree',	2,	13),
(64,	'Agree',	3,	13),
(65,	'Totally Agree',	4,	13),
(66,	'1 - Totally Disagree',	1,	14),
(67,	'2 - Disagree',	2,	14),
(68,	'3 - Rather disagree',	3,	14),
(69,	'4 - Neither agree or disagree',	4,	14),
(70,	'5 - Rather agree',	5,	14),
(71,	'6 - Agree',	6,	14),
(72,	'7 - Totally Agree',	7,	14),
(73,	'No, there was no positive impact.',	1,	15),
(74,	'The positive impact was limited.',	2,	15),
(75,	'Yes, there was a clear positive impact.',	3,	15);

CREATE TABLE `transport` (
  `id_transport` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(25) NOT NULL,
  PRIMARY KEY (`id_transport`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `type_experience` (
  `id_type_experience` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(128) NOT NULL,
  PRIMARY KEY (`id_type_experience`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `type_experience` (`id_type_experience`, `nom`) VALUES
(0,	'Other'),
(2,	'Period of study during the academic year'),
(3,	'Period of study during the summer'),
(4,	'Language school'),
(5,	'Job (waiter/waitress, manual labor, etc.)'),
(6,	'Internship (computer development, etc.)'),
(7,	'Humanitarian mission');

CREATE TABLE `type_logement` (
  `id_type_logement` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id_type_logement`),
  UNIQUE KEY `nom` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `type_logement` (`id_type_logement`, `nom`) VALUES
(2,	'A house you shared with other students'),
(1,	'A room or apartment in town'),
(4,	'A room or studio apartment on a university campus'),
(3,	'Boarder (chez l\'habitant)'),
(5,	'Hotel'),
(7,	'Other');

CREATE TABLE `ville` (
  `id_ville` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(128) NOT NULL,
  `nb_habitants` int(11) DEFAULT NULL,
  `nb_etudiants` int(11) DEFAULT NULL,
  `id_pays` int(11) NOT NULL,
  PRIMARY KEY (`id_ville`),
  UNIQUE KEY `nom` (`nom`),
  KEY `FK_ville_id_pays` (`id_pays`),
  CONSTRAINT `FK_ville_id_pays` FOREIGN KEY (`id_pays`) REFERENCES `pays` (`id_pays`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `experience_onlyrid_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `experience_onlyrid_view` AS select `e`.`id_experience` AS `id_experience_view`,sum(case when `ar`.`id_question` = '1' then `ar`.`id_reponse_possible` else NULL end) AS `study year rid`,`e`.`age` AS `age`,sum(case when `ar`.`id_question` = '4' then `ar`.`id_reponse_possible` else NULL end) AS `believe enrich rid`,sum(case when `ar`.`id_question` = '5' then `ar`.`id_reponse_possible` else NULL end) AS `believe help improve language skills rid`,sum(case when `ar`.`id_question` = '6' then `ar`.`id_reponse_possible` else NULL end) AS `believe put into practice knowledge rid`,sum(case when `ar`.`id_question` = '7' then `ar`.`id_reponse_possible` else NULL end) AS `believe make more interesting rid`,sum(case when `ar`.`id_question` = '10' then `ar`.`id_reponse_possible` else NULL end) AS `Feelings about the Mission rid`,sum(case when `ar`.`id_question` = '12' then `ar`.`id_reponse_possible` else NULL end) AS `language skills before rid`,sum(case when `ar`.`id_question` = '13' then `ar`.`id_reponse_possible` else NULL end) AS `dealing with the unknow before rid`,sum(case when `ar`.`id_question` = '14' then `ar`.`id_reponse_possible` else NULL end) AS `meeting new people before rid`,sum(case when `ar`.`id_question` = '15' then `ar`.`id_reponse_possible` else NULL end) AS `adaptability before rid`,sum(case when `ar`.`id_question` = '16' then `ar`.`id_reponse_possible` else NULL end) AS `campus rid`,`type_experience`.`nom` AS `nature of the mission`,`e`.`id_type_experience` AS `nature of the mission id`,sum(case when `ar`.`id_question` = '19' then `ar`.`id_reponse_possible` else NULL end) AS `reason for the mission rid`,`e`.`duree` AS `duration`,`organisation`.`nom` AS `organization`,`e`.`id_organisation` AS `organization id`,sum(case when `ar`.`id_question` = '26' then `ar`.`id_reponse_possible` else NULL end) AS `How did the student find out about this Mission? rid`,`e`.`competences_acquises` AS `new skills gained`,`e`.`choses_faites` AS `what did the student do ?`,`e`.`cout` AS `transport cost`,`e`.`cout_formation` AS `education cost`,`e`.`cout_alimentation` AS `food cost`,`e`.`cout_recherche_agence` AS `agency cost`,`e`.`pret` AS `loan`,`e`.`somme_empruntee` AS `borrowed money`,`logement`.`nom` AS `accommodation`,`e`.`id_logement` AS `accommodation id`,`avantage_inconvenient`.`contenu` AS `accomodation advantage`,`avantage_inconvenient`.`contenu` AS `accomodation disadvantage`,`e`.`logement_trouve` AS `How did the student find the accomodation?`,sum(case when `ar`.`id_question` = '53' then `ar`.`id_reponse_possible` else NULL end) AS `recommend rid`,`langue`.`nom` AS `language used`,`e`.`id_langue` AS `language used id`,`e`.`ressenti_langue` AS `language feeling`,`e`.`surprise` AS `what surprised the student`,`e`.`made_angry` AS `what made the student angry`,`e`.`made_laugh` AS `what made the student laugh`,`e`.`what_missed` AS `what the student missed`,`e`.`things_appreciated_want_integrate_now` AS `things from the country that the student really appreciated`,`e`.`interact_same_way` AS `differences in the way people interact`,`e`.`differences_time_organization` AS `differences in the way that time is organized`,`e`.`advice` AS `advice`,`e`.`most_difficult` AS `most difficult to get accustomed to`,sum(case when `ar`.`id_question` = '65' then `ar`.`id_reponse_possible` else NULL end) AS `financial concerns rid`,sum(case when `ar`.`id_question` = '90' then `ar`.`id_reponse_possible` else NULL end) AS `the student is happy to have had this experience rid`,sum(case when `ar`.`id_question` = '91' then `ar`.`id_reponse_possible` else NULL end) AS `The student learned a lot from this experience rid`,sum(case when `ar`.`id_question` = '92' then `ar`.`id_reponse_possible` else NULL end) AS `This experience will help the student in its future studies rid`,sum(case when `ar`.`id_question` = '93' then `ar`.`id_reponse_possible` else NULL end) AS `This experience will help the student in its future career rid`,sum(case when `ar`.`id_question` = '94' then `ar`.`id_reponse_possible` else NULL end) AS `experience part of professional development plan rid`,sum(case when `ar`.`id_question` = '95' then `ar`.`id_reponse_possible` else NULL end) AS `look great on CV rid`,sum(case when `ar`.`id_question` = '96' then `ar`.`id_reponse_possible` else NULL end) AS `improve language skills rid`,sum(case when `ar`.`id_question` = '97' then `ar`.`id_reponse_possible` else NULL end) AS `improve social skills rid`,sum(case when `ar`.`id_question` = '98' then `ar`.`id_reponse_possible` else NULL end) AS `increase self-confidence rid`,sum(case when `ar`.`id_question` = '99' then `ar`.`id_reponse_possible` else NULL end) AS `improve its ability to face difficulty rid`,sum(case when `ar`.`id_question` = '100' then `ar`.`id_reponse_possible` else NULL end) AS `less worried by new experiences rid`,sum(case when `ar`.`id_question` = '101' then `ar`.`id_reponse_possible` else NULL end) AS `started to feel at home rid`,sum(case when `ar`.`id_question` = '102' then `ar`.`id_reponse_possible` else NULL end) AS `miss certain things about the country rid`,sum(case when `ar`.`id_question` = '103' then `ar`.`id_reponse_possible` else NULL end) AS `intend to stay in touch rid`,sum(case when `ar`.`id_question` = '104' then `ar`.`id_reponse_possible` else NULL end) AS `want to return to the country rid`,sum(case when `ar`.`id_question` = '105' then `ar`.`id_reponse_possible` else NULL end) AS `want to go abroad again rid`,sum(case when `ar`.`id_question` = '106' then `ar`.`id_reponse_possible` else NULL end) AS `overall rating rid`,sum(case when `ar`.`id_question` = '107' then `ar`.`id_reponse_possible` else NULL end) AS `enrich rid`,sum(case when `ar`.`id_question` = '108' then `ar`.`id_reponse_possible` else NULL end) AS `help improve language skills rid`,sum(case when `ar`.`id_question` = '109' then `ar`.`id_reponse_possible` else NULL end) AS `put into practice knowledge rid`,sum(case when `ar`.`id_question` = '110' then `ar`.`id_reponse_possible` else NULL end) AS `made more interesting rid`,sum(case when `ar`.`id_question` = '111' then `ar`.`id_reponse_possible` else NULL end) AS `language skills rid`,sum(case when `ar`.`id_question` = '112' then `ar`.`id_reponse_possible` else NULL end) AS `dealing with the unknow rid`,sum(case when `ar`.`id_question` = '113' then `ar`.`id_reponse_possible` else NULL end) AS `meeting new people rid`,sum(case when `ar`.`id_question` = '114' then `ar`.`id_reponse_possible` else NULL end) AS `adaptability rid`,`e`.`agresso_ui` AS `AGRESSO uid`,`etudiant`.`prenom` AS `firstname`,`etudiant`.`nom` AS `lastname`,`etudiant`.`genre` AS `gender`,`etudiant`.`nom` AS `student`,`e`.`id_etudiant` AS `student id`,`ville`.`id_pays` AS `country id`,`pays`.`nom` AS `country`,`logement`.`prix` AS `accomodation cost`,`ville`.`nom` AS `city`,`organisation`.`id_ville` AS `city id`,`continent`.`nom` AS `continent`,`pays`.`id_continent` AS `continent id` from (((((((((((`experience` `e` left join `type_experience` on(`e`.`id_type_experience` = `type_experience`.`id_type_experience`)) left join `organisation` on(`e`.`id_organisation` = `organisation`.`id_organisation`)) left join `logement` on(`e`.`id_logement` = `logement`.`id_logement`)) left join `avantage_inconvenient` on(`e`.`id_avantage_logement` = `avantage_inconvenient`.`id_avantage_inconvenient`)) left join `avantage_inconvenient` `avantage_inconvenient0` on(`e`.`id_inconvenient_logement` = `avantage_inconvenient0`.`id_avantage_inconvenient`)) left join `langue` on(`e`.`id_langue` = `langue`.`id_langue`)) left join `etudiant` on(`e`.`id_etudiant` = `etudiant`.`id_etudiant`)) left join `ville` on(`organisation`.`id_ville` = `ville`.`id_ville`)) left join `pays` on(`ville`.`id_pays` = `pays`.`id_pays`)) left join `continent` on(`pays`.`id_continent` = `continent`.`id_continent`)) left join `avoir_reponse` `ar` on(`e`.`id_experience` = `ar`.`id_experience`)) group by `e`.`id_experience`;

DROP TABLE IF EXISTS `experience_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `experience_view` AS select `e`.`id_experience_view` AS `id_experience_view`,`e`.`study year rid` AS `study year rid`,`e`.`age` AS `age`,`e`.`believe enrich rid` AS `believe enrich rid`,`e`.`believe help improve language skills rid` AS `believe help improve language skills rid`,`e`.`believe put into practice knowledge rid` AS `believe put into practice knowledge rid`,`e`.`believe make more interesting rid` AS `believe make more interesting rid`,`e`.`Feelings about the Mission rid` AS `Feelings about the Mission rid`,`e`.`language skills before rid` AS `language skills before rid`,`e`.`dealing with the unknow before rid` AS `dealing with the unknow before rid`,`e`.`meeting new people before rid` AS `meeting new people before rid`,`e`.`adaptability before rid` AS `adaptability before rid`,`e`.`campus rid` AS `campus rid`,`e`.`nature of the mission` AS `nature of the mission`,`e`.`nature of the mission id` AS `nature of the mission id`,`e`.`reason for the mission rid` AS `reason for the mission rid`,`e`.`duration` AS `duration`,`e`.`organization` AS `organization`,`e`.`organization id` AS `organization id`,`e`.`How did the student find out about this Mission? rid` AS `How did the student find out about this Mission? rid`,`e`.`new skills gained` AS `new skills gained`,`e`.`what did the student do ?` AS `what did the student do ?`,`e`.`transport cost` AS `transport cost`,`e`.`education cost` AS `education cost`,`e`.`food cost` AS `food cost`,`e`.`agency cost` AS `agency cost`,`e`.`loan` AS `loan`,`e`.`borrowed money` AS `borrowed money`,`e`.`accommodation` AS `accommodation`,`e`.`accommodation id` AS `accommodation id`,`e`.`accomodation advantage` AS `accomodation advantage`,`e`.`accomodation disadvantage` AS `accomodation disadvantage`,`e`.`How did the student find the accomodation?` AS `How did the student find the accomodation?`,`e`.`recommend rid` AS `recommend rid`,`e`.`language used` AS `language used`,`e`.`language used id` AS `language used id`,`e`.`language feeling` AS `language feeling`,`e`.`what surprised the student` AS `what surprised the student`,`e`.`what made the student angry` AS `what made the student angry`,`e`.`what made the student laugh` AS `what made the student laugh`,`e`.`what the student missed` AS `what the student missed`,`e`.`things from the country that the student really appreciated` AS `things from the country that the student really appreciated`,`e`.`differences in the way people interact` AS `differences in the way people interact`,`e`.`differences in the way that time is organized` AS `differences in the way that time is organized`,`e`.`advice` AS `advice`,`e`.`most difficult to get accustomed to` AS `most difficult to get accustomed to`,`e`.`financial concerns rid` AS `financial concerns rid`,`e`.`the student is happy to have had this experience rid` AS `the student is happy to have had this experience rid`,`e`.`The student learned a lot from this experience rid` AS `The student learned a lot from this experience rid`,`e`.`This experience will help the student in its future studies rid` AS `This experience will help the student in its future studies rid`,`e`.`This experience will help the student in its future career rid` AS `This experience will help the student in its future career rid`,`e`.`experience part of professional development plan rid` AS `experience part of professional development plan rid`,`e`.`look great on CV rid` AS `look great on CV rid`,`e`.`improve language skills rid` AS `improve language skills rid`,`e`.`improve social skills rid` AS `improve social skills rid`,`e`.`increase self-confidence rid` AS `increase self-confidence rid`,`e`.`improve its ability to face difficulty rid` AS `improve its ability to face difficulty rid`,`e`.`less worried by new experiences rid` AS `less worried by new experiences rid`,`e`.`started to feel at home rid` AS `started to feel at home rid`,`e`.`miss certain things about the country rid` AS `miss certain things about the country rid`,`e`.`intend to stay in touch rid` AS `intend to stay in touch rid`,`e`.`want to return to the country rid` AS `want to return to the country rid`,`e`.`want to go abroad again rid` AS `want to go abroad again rid`,`e`.`overall rating rid` AS `overall rating rid`,`e`.`enrich rid` AS `enrich rid`,`e`.`help improve language skills rid` AS `help improve language skills rid`,`e`.`put into practice knowledge rid` AS `put into practice knowledge rid`,`e`.`made more interesting rid` AS `made more interesting rid`,`e`.`language skills rid` AS `language skills rid`,`e`.`dealing with the unknow rid` AS `dealing with the unknow rid`,`e`.`meeting new people rid` AS `meeting new people rid`,`e`.`adaptability rid` AS `adaptability rid`,`e`.`AGRESSO uid` AS `AGRESSO uid`,`e`.`firstname` AS `firstname`,`e`.`lastname` AS `lastname`,`e`.`gender` AS `gender`,`e`.`student` AS `student`,`e`.`student id` AS `student id`,`e`.`country id` AS `country id`,`e`.`country` AS `country`,`e`.`accomodation cost` AS `accomodation cost`,`e`.`city` AS `city`,`e`.`city id` AS `city id`,`e`.`continent` AS `continent`,`e`.`continent id` AS `continent id`,`rp study year`.`texte` AS `study year`,`rp study year`.`numero` AS `study year num`,`rp believe enrich`.`texte` AS `believe enrich`,`rp believe enrich`.`numero` AS `believe enrich num`,`rp believe help improve language skills`.`texte` AS `believe help improve language skills`,`rp believe help improve language skills`.`numero` AS `believe help improve language skills num`,`rp believe put into practice knowledge`.`texte` AS `believe put into practice knowledge`,`rp believe put into practice knowledge`.`numero` AS `believe put into practice knowledge num`,`rp believe make more interesting`.`texte` AS `believe make more interesting`,`rp believe make more interesting`.`numero` AS `believe make more interesting num`,`rp Feelings about the Mission`.`texte` AS `Feelings about the Mission`,`rp Feelings about the Mission`.`numero` AS `Feelings about the Mission num`,`rp language skills before`.`texte` AS `language skills before`,`rp language skills before`.`numero` AS `language skills before num`,`rp dealing with the unknow before`.`texte` AS `dealing with the unknow before`,`rp dealing with the unknow before`.`numero` AS `dealing with the unknow before num`,`rp meeting new people before`.`texte` AS `meeting new people before`,`rp meeting new people before`.`numero` AS `meeting new people before num`,`rp adaptability before`.`texte` AS `adaptability before`,`rp adaptability before`.`numero` AS `adaptability before num`,`rp campus`.`texte` AS `campus`,`rp campus`.`numero` AS `campus num`,`rp reason for the mission`.`texte` AS `reason for the mission`,`rp reason for the mission`.`numero` AS `reason for the mission num`,`rp How did the student find out about this Mission?`.`texte` AS `How did the student find out about this Mission?`,`rp How did the student find out about this Mission?`.`numero` AS `How did the student find out about this Mission? num`,`rp recommend`.`texte` AS `recommend`,`rp recommend`.`numero` AS `recommend num`,`rp financial concerns`.`texte` AS `financial concerns`,`rp financial concerns`.`numero` AS `financial concerns num`,`rp the student is happy to have had this experience`.`texte` AS `the student is happy to have had this experience`,`rp the student is happy to have had this experience`.`numero` AS `the student is happy to have had this experience num`,`rp The student learned a lot from this experience`.`texte` AS `The student learned a lot from this experience`,`rp The student learned a lot from this experience`.`numero` AS `The student learned a lot from this experience num`,`rp This experience will help the student in its future studies`.`texte` AS `This experience will help the student in its future studies`,`rp This experience will help the student in its future studies`.`numero` AS `This experience will help the student in its future studies num`,`rp This experience will help the student in its future career`.`texte` AS `This experience will help the student in its future career`,`rp This experience will help the student in its future career`.`numero` AS `This experience will help the student in its future career num`,`rp experience part of professional development plan`.`texte` AS `experience part of professional development plan`,`rp experience part of professional development plan`.`numero` AS `experience part of professional development plan num`,`rp look great on CV`.`texte` AS `look great on CV`,`rp look great on CV`.`numero` AS `look great on CV num`,`rp improve language skills`.`texte` AS `improve language skills`,`rp improve language skills`.`numero` AS `improve language skills num`,`rp improve social skills`.`texte` AS `improve social skills`,`rp improve social skills`.`numero` AS `improve social skills num`,`rp increase self-confidence`.`texte` AS `increase self-confidence`,`rp increase self-confidence`.`numero` AS `increase self-confidence num`,`rp improve its ability to face difficulty`.`texte` AS `improve its ability to face difficulty`,`rp improve its ability to face difficulty`.`numero` AS `improve its ability to face difficulty num`,`rp less worried by new experiences`.`texte` AS `less worried by new experiences`,`rp less worried by new experiences`.`numero` AS `less worried by new experiences num`,`rp started to feel at home`.`texte` AS `started to feel at home`,`rp started to feel at home`.`numero` AS `started to feel at home num`,`rp miss certain things about the country`.`texte` AS `miss certain things about the country`,`rp miss certain things about the country`.`numero` AS `miss certain things about the country num`,`rp intend to stay in touch`.`texte` AS `intend to stay in touch`,`rp intend to stay in touch`.`numero` AS `intend to stay in touch num`,`rp want to return to the country`.`texte` AS `want to return to the country`,`rp want to return to the country`.`numero` AS `want to return to the country num`,`rp want to go abroad again`.`texte` AS `want to go abroad again`,`rp want to go abroad again`.`numero` AS `want to go abroad again num`,`rp overall rating`.`texte` AS `overall rating`,`rp overall rating`.`numero` AS `overall rating num`,`rp enrich`.`texte` AS `enrich`,`rp enrich`.`numero` AS `enrich num`,`rp help improve language skills`.`texte` AS `help improve language skills`,`rp help improve language skills`.`numero` AS `help improve language skills num`,`rp put into practice knowledge`.`texte` AS `put into practice knowledge`,`rp put into practice knowledge`.`numero` AS `put into practice knowledge num`,`rp made more interesting`.`texte` AS `made more interesting`,`rp made more interesting`.`numero` AS `made more interesting num`,`rp language skills`.`texte` AS `language skills`,`rp language skills`.`numero` AS `language skills num`,`rp dealing with the unknow`.`texte` AS `dealing with the unknow`,`rp dealing with the unknow`.`numero` AS `dealing with the unknow num`,`rp meeting new people`.`texte` AS `meeting new people`,`rp meeting new people`.`numero` AS `meeting new people num`,`rp adaptability`.`texte` AS `adaptability`,`rp adaptability`.`numero` AS `adaptability num` from ((((((((((((((((((((((((((((((((((((((((`experience_onlyrid_view` `e` left join `reponse_possible` `rp study year` on(`rp study year`.`id_reponse_possible` = `e`.`study year rid`)) left join `reponse_possible` `rp believe enrich` on(`rp believe enrich`.`id_reponse_possible` = `e`.`believe enrich rid`)) left join `reponse_possible` `rp believe help improve language skills` on(`rp believe help improve language skills`.`id_reponse_possible` = `e`.`believe help improve language skills rid`)) left join `reponse_possible` `rp believe put into practice knowledge` on(`rp believe put into practice knowledge`.`id_reponse_possible` = `e`.`believe put into practice knowledge rid`)) left join `reponse_possible` `rp believe make more interesting` on(`rp believe make more interesting`.`id_reponse_possible` = `e`.`believe make more interesting rid`)) left join `reponse_possible` `rp Feelings about the Mission` on(`rp Feelings about the Mission`.`id_reponse_possible` = `e`.`Feelings about the Mission rid`)) left join `reponse_possible` `rp language skills before` on(`rp language skills before`.`id_reponse_possible` = `e`.`language skills before rid`)) left join `reponse_possible` `rp dealing with the unknow before` on(`rp dealing with the unknow before`.`id_reponse_possible` = `e`.`dealing with the unknow before rid`)) left join `reponse_possible` `rp meeting new people before` on(`rp meeting new people before`.`id_reponse_possible` = `e`.`meeting new people before rid`)) left join `reponse_possible` `rp adaptability before` on(`rp adaptability before`.`id_reponse_possible` = `e`.`adaptability before rid`)) left join `reponse_possible` `rp campus` on(`rp campus`.`id_reponse_possible` = `e`.`campus rid`)) left join `reponse_possible` `rp reason for the mission` on(`rp reason for the mission`.`id_reponse_possible` = `e`.`reason for the mission rid`)) left join `reponse_possible` `rp How did the student find out about this Mission?` on(`rp How did the student find out about this Mission?`.`id_reponse_possible` = `e`.`How did the student find out about this Mission? rid`)) left join `reponse_possible` `rp recommend` on(`rp recommend`.`id_reponse_possible` = `e`.`recommend rid`)) left join `reponse_possible` `rp financial concerns` on(`rp financial concerns`.`id_reponse_possible` = `e`.`financial concerns rid`)) left join `reponse_possible` `rp the student is happy to have had this experience` on(`rp the student is happy to have had this experience`.`id_reponse_possible` = `e`.`the student is happy to have had this experience rid`)) left join `reponse_possible` `rp The student learned a lot from this experience` on(`rp The student learned a lot from this experience`.`id_reponse_possible` = `e`.`The student learned a lot from this experience rid`)) left join `reponse_possible` `rp This experience will help the student in its future studies` on(`rp This experience will help the student in its future studies`.`id_reponse_possible` = `e`.`This experience will help the student in its future studies rid`)) left join `reponse_possible` `rp This experience will help the student in its future career` on(`rp This experience will help the student in its future career`.`id_reponse_possible` = `e`.`This experience will help the student in its future career rid`)) left join `reponse_possible` `rp experience part of professional development plan` on(`rp experience part of professional development plan`.`id_reponse_possible` = `e`.`experience part of professional development plan rid`)) left join `reponse_possible` `rp look great on CV` on(`rp look great on CV`.`id_reponse_possible` = `e`.`look great on CV rid`)) left join `reponse_possible` `rp improve language skills` on(`rp improve language skills`.`id_reponse_possible` = `e`.`improve language skills rid`)) left join `reponse_possible` `rp improve social skills` on(`rp improve social skills`.`id_reponse_possible` = `e`.`improve social skills rid`)) left join `reponse_possible` `rp increase self-confidence` on(`rp increase self-confidence`.`id_reponse_possible` = `e`.`increase self-confidence rid`)) left join `reponse_possible` `rp improve its ability to face difficulty` on(`rp improve its ability to face difficulty`.`id_reponse_possible` = `e`.`improve its ability to face difficulty rid`)) left join `reponse_possible` `rp less worried by new experiences` on(`rp less worried by new experiences`.`id_reponse_possible` = `e`.`less worried by new experiences rid`)) left join `reponse_possible` `rp started to feel at home` on(`rp started to feel at home`.`id_reponse_possible` = `e`.`started to feel at home rid`)) left join `reponse_possible` `rp miss certain things about the country` on(`rp miss certain things about the country`.`id_reponse_possible` = `e`.`miss certain things about the country rid`)) left join `reponse_possible` `rp intend to stay in touch` on(`rp intend to stay in touch`.`id_reponse_possible` = `e`.`intend to stay in touch rid`)) left join `reponse_possible` `rp want to return to the country` on(`rp want to return to the country`.`id_reponse_possible` = `e`.`want to return to the country rid`)) left join `reponse_possible` `rp want to go abroad again` on(`rp want to go abroad again`.`id_reponse_possible` = `e`.`want to go abroad again rid`)) left join `reponse_possible` `rp overall rating` on(`rp overall rating`.`id_reponse_possible` = `e`.`overall rating rid`)) left join `reponse_possible` `rp enrich` on(`rp enrich`.`id_reponse_possible` = `e`.`enrich rid`)) left join `reponse_possible` `rp help improve language skills` on(`rp help improve language skills`.`id_reponse_possible` = `e`.`help improve language skills rid`)) left join `reponse_possible` `rp put into practice knowledge` on(`rp put into practice knowledge`.`id_reponse_possible` = `e`.`put into practice knowledge rid`)) left join `reponse_possible` `rp made more interesting` on(`rp made more interesting`.`id_reponse_possible` = `e`.`made more interesting rid`)) left join `reponse_possible` `rp language skills` on(`rp language skills`.`id_reponse_possible` = `e`.`language skills rid`)) left join `reponse_possible` `rp dealing with the unknow` on(`rp dealing with the unknow`.`id_reponse_possible` = `e`.`dealing with the unknow rid`)) left join `reponse_possible` `rp meeting new people` on(`rp meeting new people`.`id_reponse_possible` = `e`.`meeting new people rid`)) left join `reponse_possible` `rp adaptability` on(`rp adaptability`.`id_reponse_possible` = `e`.`adaptability rid`));

-- 2020-06-28 00:29:20
